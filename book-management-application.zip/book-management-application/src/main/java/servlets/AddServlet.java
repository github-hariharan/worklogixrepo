package servlets;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet ( urlPatterns = { "/add" } )
public class AddServlet extends HttpServlet {
	Connection dbconnection = null;
	private static Integer uniqueId;
	final private String CONNECTIONSTRING = "jdbc:mysql://remotemysql.com/BHbvfN8oj8";
	final private String USERNAME = "BHbvfN8oj8";
	final private String PASSWORD = "qyzIhs8nQU";
	
	@Override
	public void init() {
		try {
			uniqueId = 1001;
			Class.forName("com.mysql.jdbc.Driver");
			
			dbconnection = DriverManager.getConnection(CONNECTIONSTRING, USERNAME, PASSWORD);
		
			System.out.println("Database connection status : success");
			
		// checking for book table exist if it is not create	
			DatabaseMetaData dbm = dbconnection.getMetaData();
		    ResultSet rs = dbm.getTables(null, null, "book", null);
		    if (rs.next()) {
		      System.out.println("Book table exist in db");
		    } else {
		      System.out.println("Book table not existing in db so creating book table");
		      Statement statement = dbconnection.createStatement();
			  String sqlQuery = "create table book(id integer not null, name varchar(255), authorname varchar(255)," +
								  "price float, type varchar(255), primary key(id))";
			  statement.executeUpdate(sqlQuery);
			  
		    }
			
		} catch(SQLException sqlexc) {
			sqlexc.printStackTrace();
		}
		catch(Exception e){
			e.printStackTrace();
		} finally {
			try {
				if(dbconnection != null) {
					dbconnection.close();
					System.out.println("database connection closed");
				}
				
			} catch(SQLException sqlexc) {
				sqlexc.printStackTrace();
			}
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) {
		Book newBook = new Book();
		newBook.setId(AddServlet.uniqueId);
		newBook.setName(request.getParameter("bookname"));
		newBook.setAuthor(request.getParameter("bookauthor"));
		String bookPrice = request.getParameter("bookprice");
		if(bookPrice.isEmpty()) {
			bookPrice = "0";
		}
		newBook.setPrice(new Double(bookPrice));
		newBook.setType(request.getParameter("booktype"));
		
		//inserting new book to database
		String query = "insert into book(id,name,authorname,price, type) values(?,?,?,?,?)";
		try {
			dbconnection = DriverManager.getConnection(CONNECTIONSTRING, USERNAME, PASSWORD);
			PreparedStatement preparedStatement = dbconnection.prepareStatement(query);
			preparedStatement.setInt(1, newBook.getId());
			preparedStatement.setString(2, newBook.getName());
			preparedStatement.setString(3, newBook.getAuthor());
			preparedStatement.setDouble(4, newBook.getPrice());
			preparedStatement.setString(5, newBook.getType());
			
			preparedStatement.execute();
			uniqueId++;
			
			
		} catch(Exception exc) {
			exc.printStackTrace();
		} 
	
	}
	
	@Override
	public void destroy() {
		try {
			if(dbconnection != null) {
				dbconnection.close();
			}
		} catch(Exception exc) {
			exc.printStackTrace();
		}
	}
	
}