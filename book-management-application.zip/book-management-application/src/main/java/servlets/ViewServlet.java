package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet ( urlPatterns = { "/view" } ) 
public class ViewServlet extends HttpServlet {
	
	Connection dbconnection = null;
	final private String CONNECTIONSTRING = "jdbc:mysql://remotemysql.com/BHbvfN8oj8";
	final private String USERNAME = "BHbvfN8oj8";
	final private String PASSWORD = "qyzIhs8nQU";
	
	@Override
	public void init() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			dbconnection = DriverManager.getConnection(CONNECTIONSTRING, USERNAME, PASSWORD);
		
			System.out.println("Database connection status : success");
			
		// checking for book table exist if it is not create	
			DatabaseMetaData dbm = dbconnection.getMetaData();
		    ResultSet rs = dbm.getTables(null, null, "book", null);
		    if (rs.next()) {
		      System.out.println("Book table exist in db");
		    } else {
		    	throw new Exception("BOOK TABLE NOT EXIST");
		    }
		    
			
		} catch(SQLException sqlexc) {
			sqlexc.printStackTrace();
		}
		catch(Exception e){
			e.printStackTrace();
		} finally {
			try {
				if(dbconnection != null) {
					dbconnection.close();
					System.out.println("database connection closed");
				}
				
			} catch(SQLException sqlexc) {
				sqlexc.printStackTrace();
			}
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		try {
			response.setContentType("text/html");
			dbconnection = DriverManager.getConnection(CONNECTIONSTRING, USERNAME, PASSWORD);
			Statement statement = dbconnection.createStatement();
			ResultSet resultSet = statement.executeQuery("select * from book");
			
			PrintWriter out = response.getWriter();
			out.println("<html><body>");
			
			Book book = new Book();
			while(resultSet.next()) {
				book.setId(resultSet.getInt("id"));
				book.setName(resultSet.getString("name"));
				book.setAuthor(resultSet.getString("authorname"));
				book.setPrice(resultSet.getDouble("price"));
				book.setType(resultSet.getString("type"));
				out.println(book + "<br/>");
				
			}
			out.println("</body></html>");
			out.close();
		} catch(IOException ioe) {
			ioe.printStackTrace();
		} catch(SQLException sqlexc) {
			sqlexc.printStackTrace();
		} finally {
			try {
			if(dbconnection != null) {
				dbconnection.close();
			}
			} catch(Exception exc) {
				exc.printStackTrace();
			}
			
		}
	}
	
}